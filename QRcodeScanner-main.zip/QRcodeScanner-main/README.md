# QRcodeScanner
this repo has lWC and Apex Controller to create "Package" sObject records. It handles duplicate records by checking if newly scanned package is alredy exists.
